export interface PatientData {
  id: string;
  name: string;
  age: number;
  gender: string;
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high';
  lastScan: string;
  diagnosis: string;
  vitalSigns: {
    heartRate: number;
    bloodPressure: string;
    temperature: number;
    oxygenSaturation: number;
  };
}

export interface ScanResult {
  id: string;
  patientId: string;
  date: string;
  scanType: string;
  findings: string;
  confidence: number;
  imageUrl: string;
  aiAnnotated: boolean;
}

export interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor: string | string[];
    borderColor?: string | string[];
    borderWidth?: number;
  }[];
}