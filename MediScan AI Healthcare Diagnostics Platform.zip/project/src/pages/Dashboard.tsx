import React from 'react';
import { Users, Activity, Calendar, FileText, TrendingUp, ChevronRight } from 'lucide-react';
import StatCard from '../components/Dashboard/StatCard';
import ChartCard from '../components/Dashboard/ChartCard';
import PatientCard from '../components/Patients/PatientCard';
import { patients } from '../data/mockData';
import { getDemoChartData } from '../data/mockData';
import { useNavigate } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { riskDistribution, scanTypes, diagnosisAccuracy, weeklyScans } = getDemoChartData();

  const handlePatientClick = (id: string) => {
    navigate(`/patients/${id}`);
  };

  // Get high-risk patients
  const highRiskPatients = patients.filter(patient => patient.riskLevel === 'high');

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
            <p className="text-gray-500 mt-1">Welcome back to MediScan AI</p>
          </div>
          <div className="mt-4 sm:mt-0">
            <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-150 flex items-center">
              <Calendar size={18} className="mr-2" />
              <span>Today's Schedule</span>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Patients"
            value="1,248"
            icon={<Users size={20} />}
            change={{ value: 12, isPositive: true }}
          />
          <StatCard
            title="Scans This Week"
            value="148"
            icon={<Activity size={20} />}
            change={{ value: 8, isPositive: true }}
          />
          <StatCard
            title="AI Diagnosis Accuracy"
            value="94%"
            icon={<TrendingUp size={20} />}
            change={{ value: 2, isPositive: true }}
          />
          <StatCard
            title="Reports Generated"
            value="892"
            icon={<FileText size={20} />}
            change={{ value: 5, isPositive: true }}
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <ChartCard
            title="Weekly Scan Volume"
            subtitle="Number of scans processed per day"
            chartType="line"
            data={weeklyScans}
          />
          <ChartCard
            title="Patient Risk Distribution"
            subtitle="Breakdown by risk level"
            chartType="doughnut"
            data={riskDistribution}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <ChartCard
            title="Scan Types"
            subtitle="Distribution by imaging modality"
            chartType="doughnut"
            data={scanTypes}
          />
          <ChartCard
            title="AI Diagnosis Accuracy Trend"
            subtitle="Monthly accuracy improvements"
            chartType="line"
            data={diagnosisAccuracy}
          />
        </div>

        {/* High-risk patients */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-800">High Risk Patients</h2>
            <button 
              className="text-primary-600 hover:text-primary-800 flex items-center text-sm font-medium"
              onClick={() => navigate('/patients')}
            >
              View All
              <ChevronRight size={16} />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {highRiskPatients.map(patient => (
              <PatientCard 
                key={patient.id} 
                patient={patient} 
                onClick={handlePatientClick}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;