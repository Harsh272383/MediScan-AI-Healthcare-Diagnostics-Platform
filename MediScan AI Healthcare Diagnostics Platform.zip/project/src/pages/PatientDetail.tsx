import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, ChevronRight, Zap } from 'lucide-react';
import { patients, scanResults } from '../data/mockData';
import ScanDetail from '../components/ScanAnalyzer/ScanDetail';

const PatientDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const patient = patients.find(p => p.id === id);
  const patientScans = scanResults.filter(scan => scan.patientId === id);
  
  if (!patient) {
    return (
      <div className="flex-1 p-6">
        <div className="max-w-4xl mx-auto text-center py-12">
          <h2 className="text-xl font-semibold text-gray-900">Patient not found</h2>
          <p className="mt-2 text-gray-500">The patient you're looking for doesn't exist or you don't have access.</p>
          <div className="mt-6">
            <Link 
              to="/patients" 
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back to Patients
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'bg-secondary-100 text-secondary-800 border-secondary-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'high':
        return 'bg-accent-100 text-accent-800 border-accent-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <Link 
            to="/patients" 
            className="inline-flex items-center text-sm font-medium text-primary-600 hover:text-primary-800"
          >
            <ArrowLeft size={16} className="mr-1" />
            Back to Patients
          </Link>
        </div>

        {/* Patient header */}
        <div className="bg-white rounded-xl shadow-card p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">{patient.name}</h1>
              <p className="text-gray-500 mt-1">
                {patient.age} years • {patient.gender} • Patient ID: {patient.id}
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex items-center space-x-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(patient.riskLevel)} border`}>
                {patient.riskLevel.charAt(0).toUpperCase() + patient.riskLevel.slice(1)} Risk
              </span>
              <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-150 flex items-center">
                <Calendar size={18} className="mr-2" />
                <span>Schedule Follow-up</span>
              </button>
            </div>
          </div>
        </div>

        {/* Patient details section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-card p-6 lg:col-span-2">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Diagnosis Summary</h2>
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Current Diagnosis</h3>
              <p className="text-gray-800">{patient.diagnosis}</p>
            </div>
            
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-500 mb-2">AI Risk Assessment</h3>
              <div className="bg-gray-100 rounded-full h-4 mb-2">
                <div 
                  className={`h-4 rounded-full ${
                    patient.riskLevel === 'low' ? 'bg-secondary-500' : 
                    patient.riskLevel === 'medium' ? 'bg-yellow-500' : 'bg-accent-500'
                  }`}
                  style={{ width: `${patient.riskScore}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span>Low Risk</span>
                <span>Medium Risk</span>
                <span>High Risk</span>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-2">AI Recommendations</h3>
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Zap className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-blue-700">
                      {patient.riskLevel === 'high' 
                        ? 'Immediate follow-up recommended. Consider additional diagnostic imaging and specialist consultation.'
                        : patient.riskLevel === 'medium'
                          ? 'Routine follow-up in 3 months. Monitor for changes in symptoms.'
                          : 'Annual check-up recommended. No immediate concerns detected.'
                      }
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-card p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Vital Signs</h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Heart Rate</h3>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-2xl font-bold text-gray-800">{patient.vitalSigns.heartRate}</span>
                  <span className="text-sm text-gray-500">bpm</span>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Blood Pressure</h3>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-2xl font-bold text-gray-800">{patient.vitalSigns.bloodPressure}</span>
                  <span className="text-sm text-gray-500">mmHg</span>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Temperature</h3>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-2xl font-bold text-gray-800">{patient.vitalSigns.temperature}</span>
                  <span className="text-sm text-gray-500">°F</span>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Oxygen Saturation</h3>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-2xl font-bold text-gray-800">{patient.vitalSigns.oxygenSaturation}</span>
                  <span className="text-sm text-gray-500">%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scans section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Recent Scans</h2>
            <Link 
              to="/scan-analyzer" 
              className="text-primary-600 hover:text-primary-800 flex items-center text-sm font-medium"
            >
              View All Scans
              <ChevronRight size={16} />
            </Link>
          </div>
          
          <div className="space-y-6">
            {patientScans.length > 0 ? (
              patientScans.map(scan => (
                <ScanDetail key={scan.id} scan={scan} />
              ))
            ) : (
              <div className="bg-white rounded-xl shadow-card p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900">No scans found</h3>
                <p className="mt-1 text-sm text-gray-500">
                  This patient doesn't have any scans yet
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDetail;