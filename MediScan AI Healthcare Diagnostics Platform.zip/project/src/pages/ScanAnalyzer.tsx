import React, { useState } from 'react';
import { scanResults } from '../data/mockData';
import ScanDetail from '../components/ScanAnalyzer/ScanDetail';
import UploadScan from '../components/ScanAnalyzer/UploadScan';
import { Search, Filter, ChevronDown } from 'lucide-react';

const ScanAnalyzer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'upload'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [confidenceFilter, setConfidenceFilter] = useState<string>('all');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedScan, setSelectedScan] = useState<string | null>(scanResults[0]?.id || null);

  const handleTabChange = (tab: 'all' | 'upload') => {
    setActiveTab(tab);
  };

  const filteredScans = scanResults.filter(scan => {
    const matchesSearch = 
      scan.findings.toLowerCase().includes(searchTerm.toLowerCase()) ||
      scan.scanType.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (confidenceFilter === 'all') return matchesSearch;
    if (confidenceFilter === 'high') return matchesSearch && scan.confidence >= 90;
    if (confidenceFilter === 'medium') return matchesSearch && scan.confidence >= 75 && scan.confidence < 90;
    if (confidenceFilter === 'low') return matchesSearch && scan.confidence < 75;
    
    return matchesSearch;
  });

  const currentScan = scanResults.find(scan => scan.id === selectedScan);

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-800 mb-8">Scan Analyzer</h1>

        {/* Tabs */}
        <div className="bg-white rounded-t-xl shadow-card">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px" aria-label="Tabs">
              <button
                className={`
                  py-4 px-8 font-medium text-sm border-b-2 transition-colors duration-150
                  ${activeTab === 'all' 
                    ? 'border-primary-600 text-primary-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
                onClick={() => handleTabChange('all')}
              >
                All Scans
              </button>
              <button
                className={`
                  py-4 px-8 font-medium text-sm border-b-2 transition-colors duration-150
                  ${activeTab === 'upload' 
                    ? 'border-primary-600 text-primary-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
                onClick={() => handleTabChange('upload')}
              >
                Upload New Scan
              </button>
            </nav>
          </div>
        </div>

        {activeTab === 'all' ? (
          <div className="bg-white rounded-b-xl shadow-card p-6">
            {/* Search and filters */}
            <div className="mb-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    placeholder="Search scans by type or findings..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div className="relative">
                  <button
                    type="button"
                    className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    onClick={() => setIsFilterOpen(!isFilterOpen)}
                  >
                    <Filter size={18} className="mr-2 text-gray-500" />
                    Filter by confidence
                    <ChevronDown size={16} className="ml-2 text-gray-500" />
                  </button>
                  
                  {isFilterOpen && (
                    <div className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                      <div className="py-1" role="menu" aria-orientation="vertical">
                        <button
                          className={`block px-4 py-2 text-sm w-full text-left ${confidenceFilter === 'all' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                          onClick={() => { setConfidenceFilter('all'); setIsFilterOpen(false); }}
                        >
                          All Confidence Levels
                        </button>
                        <button
                          className={`block px-4 py-2 text-sm w-full text-left ${confidenceFilter === 'high' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                          onClick={() => { setConfidenceFilter('high'); setIsFilterOpen(false); }}
                        >
                          High Confidence (90%+)
                        </button>
                        <button
                          className={`block px-4 py-2 text-sm w-full text-left ${confidenceFilter === 'medium' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                          onClick={() => { setConfidenceFilter('medium'); setIsFilterOpen(false); }}
                        >
                          Medium Confidence (75-89%)
                        </button>
                        <button
                          className={`block px-4 py-2 text-sm w-full text-left ${confidenceFilter === 'low' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                          onClick={() => { setConfidenceFilter('low'); setIsFilterOpen(false); }}
                        >
                          Low Confidence (&lt;75%)
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Scans list and detail view */}
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-1 bg-gray-50 rounded-lg p-4 h-[calc(100vh-300px)] overflow-y-auto">
                <h3 className="text-sm font-medium text-gray-500 mb-3">Available Scans</h3>
                <div className="space-y-2">
                  {filteredScans.length > 0 ? (
                    filteredScans.map(scan => (
                      <div
                        key={scan.id}
                        onClick={() => setSelectedScan(scan.id)}
                        className={`
                          cursor-pointer p-3 rounded-lg transition-colors duration-150
                          ${selectedScan === scan.id 
                            ? 'bg-primary-100 border-l-4 border-primary-600' 
                            : 'bg-white hover:bg-gray-100'}
                        `}
                      >
                        <h4 className="font-medium text-gray-800">{scan.scanType}</h4>
                        <p className="text-xs text-gray-500 mt-1">{new Date(scan.date).toLocaleDateString()}</p>
                        <div className="flex items-center mt-2">
                          <div 
                            className={`h-2 rounded-full flex-grow ${
                              scan.confidence >= 90 ? 'bg-secondary-500' : 
                              scan.confidence >= 75 ? 'bg-yellow-500' : 
                              'bg-accent-500'
                            }`}
                          ></div>
                          <span className="text-xs font-medium ml-2">{scan.confidence}%</span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-500">No scans match your filters</p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="lg:col-span-3">
                {currentScan ? (
                  <ScanDetail scan={currentScan} />
                ) : (
                  <div className="bg-white rounded-xl shadow-card p-8 text-center">
                    <h3 className="text-lg font-medium text-gray-900">No scan selected</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Select a scan from the list to view details
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <UploadScan />
        )}
      </div>
    </div>
  );
};

export default ScanAnalyzer;