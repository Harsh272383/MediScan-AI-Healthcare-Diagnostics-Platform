import React, { useState } from 'react';
import { Search, Filter, Plus, ChevronDown } from 'lucide-react';
import PatientCard from '../components/Patients/PatientCard';
import { patients } from '../data/mockData';
import { useNavigate } from 'react-router-dom';

const PatientsList: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const handlePatientClick = (id: string) => {
    navigate(`/patients/${id}`);
  };

  const filteredPatients = patients.filter(patient => {
    const matchesSearch = patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient.diagnosis.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk = riskFilter === 'all' || patient.riskLevel === riskFilter;
    return matchesSearch && matchesRisk;
  });

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-800">Patients</h1>
          <button className="mt-4 sm:mt-0 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-150 flex items-center justify-center">
            <Plus size={18} className="mr-2" />
            <span>New Patient</span>
          </button>
        </div>

        {/* Search and filters */}
        <div className="bg-white rounded-xl shadow-card p-4 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                placeholder="Search patients by name or diagnosis..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="relative">
              <button
                type="button"
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                onClick={() => setIsFilterOpen(!isFilterOpen)}
              >
                <Filter size={18} className="mr-2 text-gray-500" />
                Filter by risk
                <ChevronDown size={16} className="ml-2 text-gray-500" />
              </button>
              
              {isFilterOpen && (
                <div className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                  <div className="py-1" role="menu" aria-orientation="vertical">
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${riskFilter === 'all' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setRiskFilter('all'); setIsFilterOpen(false); }}
                    >
                      All Patients
                    </button>
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${riskFilter === 'low' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setRiskFilter('low'); setIsFilterOpen(false); }}
                    >
                      Low Risk
                    </button>
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${riskFilter === 'medium' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setRiskFilter('medium'); setIsFilterOpen(false); }}
                    >
                      Medium Risk
                    </button>
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${riskFilter === 'high' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setRiskFilter('high'); setIsFilterOpen(false); }}
                    >
                      High Risk
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Patients grid */}
        {filteredPatients.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPatients.map(patient => (
              <PatientCard 
                key={patient.id} 
                patient={patient} 
                onClick={handlePatientClick}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-card p-8 text-center">
            <h3 className="text-lg font-medium text-gray-900">No patients found</h3>
            <p className="mt-1 text-sm text-gray-500">
              Try adjusting your search or filter criteria
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PatientsList;