import React, { useState } from 'react';
import { File, Download, Filter, Search, ChevronDown, Printer } from 'lucide-react';
import { patients, scanResults } from '../data/mockData';

interface Report {
  id: string;
  patientId: string;
  patientName: string;
  type: string;
  date: string;
  status: 'completed' | 'pending' | 'in-review';
}

const Reports: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Generate mock reports based on scan results
  const mockReports: Report[] = scanResults.map((scan, index) => {
    const patient = patients.find(p => p.id === scan.patientId);
    return {
      id: `REP${1000 + index}`,
      patientId: scan.patientId,
      patientName: patient?.name || 'Unknown Patient',
      type: `${scan.scanType} Analysis`,
      date: scan.date,
      status: index % 3 === 0 ? 'pending' : index % 5 === 0 ? 'in-review' : 'completed',
    };
  });

  const filteredReports = mockReports.filter(report => {
    const matchesSearch = 
      report.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (statusFilter === 'all') return matchesSearch;
    return matchesSearch && report.status === statusFilter;
  });

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-secondary-100 text-secondary-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'in-review':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-800 mb-8">Reports</h1>

        {/* Search and filters */}
        <div className="bg-white rounded-xl shadow-card p-4 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={18} className="text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                placeholder="Search reports by patient name, type, or ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="relative">
              <button
                type="button"
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                onClick={() => setIsFilterOpen(!isFilterOpen)}
              >
                <Filter size={18} className="mr-2 text-gray-500" />
                Filter by status
                <ChevronDown size={16} className="ml-2 text-gray-500" />
              </button>
              
              {isFilterOpen && (
                <div className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                  <div className="py-1" role="menu" aria-orientation="vertical">
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${statusFilter === 'all' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setStatusFilter('all'); setIsFilterOpen(false); }}
                    >
                      All Reports
                    </button>
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${statusFilter === 'completed' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setStatusFilter('completed'); setIsFilterOpen(false); }}
                    >
                      Completed
                    </button>
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${statusFilter === 'pending' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setStatusFilter('pending'); setIsFilterOpen(false); }}
                    >
                      Pending
                    </button>
                    <button
                      className={`block px-4 py-2 text-sm w-full text-left ${statusFilter === 'in-review' ? 'bg-gray-100 text-gray-900' : 'text-gray-700'}`}
                      onClick={() => { setStatusFilter('in-review'); setIsFilterOpen(false); }}
                    >
                      In Review
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Reports table */}
        <div className="bg-white rounded-xl shadow-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Report ID
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Patient
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredReports.length > 0 ? (
                  filteredReports.map((report) => (
                    <tr key={report.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <File size={18} className="text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900">{report.id}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{report.patientName}</div>
                        <div className="text-xs text-gray-500">ID: {report.patientId}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {report.type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(report.date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(report.status)}`}>
                          {report.status.charAt(0).toUpperCase() + report.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-3">
                          <button className="text-gray-500 hover:text-gray-700">
                            <Printer size={18} />
                          </button>
                          <button className="text-primary-600 hover:text-primary-800">
                            <Download size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-10 text-center text-sm text-gray-500">
                      No reports found matching your criteria
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;