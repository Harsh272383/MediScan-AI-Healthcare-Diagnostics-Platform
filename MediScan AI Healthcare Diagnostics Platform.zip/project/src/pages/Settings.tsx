import React, { useState } from 'react';
import { Save, AlertCircle } from 'lucide-react';

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'general' | 'ai' | 'notifications' | 'security'>('general');
  
  // Mock settings
  const [settings, setSettings] = useState({
    general: {
      systemName: 'MediScan AI',
      language: 'en',
      theme: 'light',
      dateFormat: 'MM/DD/YYYY',
    },
    ai: {
      confidenceThreshold: 75,
      enableAutoAnalysis: true,
      saveAIAnnotations: true,
      modelVersion: 'v2.3.1',
    },
    notifications: {
      emailAlerts: true,
      highRiskAlerts: true,
      scanCompletionNotifications: true,
      weeklyReports: false,
    },
    security: {
      twoFactorAuth: false,
      sessionTimeout: 30,
      dataEncryption: true,
    },
  });

  const handleTabChange = (tab: 'general' | 'ai' | 'notifications' | 'security') => {
    setActiveTab(tab);
  };

  const handleInputChange = (section: string, field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [field]: value,
      },
    }));
  };

  const handleSaveSettings = () => {
    // In a real app, this would save to backend
    console.log('Saving settings:', settings);
    // Show success message
    alert('Settings saved successfully!');
  };

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-800 mb-8">Settings</h1>

        <div className="bg-white rounded-xl shadow-card overflow-hidden">
          <div className="sm:flex sm:divide-x">
            {/* Sidebar */}
            <nav className="px-4 py-5 sm:px-6 sm:w-64 bg-gray-50">
              <div className="space-y-1">
                {[
                  { id: 'general', label: 'General Settings' },
                  { id: 'ai', label: 'AI Configuration' },
                  { id: 'notifications', label: 'Notifications' },
                  { id: 'security', label: 'Security' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleTabChange(item.id as any)}
                    className={`
                      w-full text-left px-3 py-2 text-sm font-medium rounded-md transition-colors duration-150 ease-in-out
                      ${activeTab === item.id 
                        ? 'bg-primary-100 text-primary-800' 
                        : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}
                    `}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </nav>

            {/* Content area */}
            <div className="flex-1 px-4 py-5 sm:p-6">
              {activeTab === 'general' && (
                <div>
                  <h2 className="text-lg font-medium text-gray-900 mb-4">General Settings</h2>
                  
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="systemName" className="block text-sm font-medium text-gray-700">
                        System Name
                      </label>
                      <input
                        type="text"
                        id="systemName"
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        value={settings.general.systemName}
                        onChange={(e) => handleInputChange('general', 'systemName', e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="language" className="block text-sm font-medium text-gray-700">
                        Language
                      </label>
                      <select
                        id="language"
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        value={settings.general.language}
                        onChange={(e) => handleInputChange('general', 'language', e.target.value)}
                      >
                        <option value="en">English</option>
                        <option value="es">Spanish</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="theme" className="block text-sm font-medium text-gray-700">
                        Theme
                      </label>
                      <select
                        id="theme"
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        value={settings.general.theme}
                        onChange={(e) => handleInputChange('general', 'theme', e.target.value)}
                      >
                        <option value="light">Light</option>
                        <option value="dark">Dark</option>
                        <option value="system">System Default</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="dateFormat" className="block text-sm font-medium text-gray-700">
                        Date Format
                      </label>
                      <select
                        id="dateFormat"
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        value={settings.general.dateFormat}
                        onChange={(e) => handleInputChange('general', 'dateFormat', e.target.value)}
                      >
                        <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                        <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                        <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'ai' && (
                <div>
                  <h2 className="text-lg font-medium text-gray-900 mb-4">AI Configuration</h2>
                  
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="confidenceThreshold" className="block text-sm font-medium text-gray-700">
                        AI Confidence Threshold (%)
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        id="confidenceThreshold"
                        className="mt-1 block w-full"
                        value={settings.ai.confidenceThreshold}
                        onChange={(e) => handleInputChange('ai', 'confidenceThreshold', parseInt(e.target.value))}
                      />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>0%</span>
                        <span>{settings.ai.confidenceThreshold}%</span>
                        <span>100%</span>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="enableAutoAnalysis"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.ai.enableAutoAnalysis}
                          onChange={(e) => handleInputChange('ai', 'enableAutoAnalysis', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="enableAutoAnalysis" className="font-medium text-gray-700">Enable Automatic Analysis</label>
                        <p className="text-gray-500">Automatically analyze new scans when they are uploaded</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="saveAIAnnotations"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.ai.saveAIAnnotations}
                          onChange={(e) => handleInputChange('ai', 'saveAIAnnotations', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="saveAIAnnotations" className="font-medium text-gray-700">Save AI Annotations</label>
                        <p className="text-gray-500">Save AI-generated annotations with scan results</p>
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="modelVersion" className="block text-sm font-medium text-gray-700">
                        AI Model Version
                      </label>
                      <select
                        id="modelVersion"
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        value={settings.ai.modelVersion}
                        onChange={(e) => handleInputChange('ai', 'modelVersion', e.target.value)}
                      >
                        <option value="v2.3.1">v2.3.1 (Latest)</option>
                        <option value="v2.2.0">v2.2.0</option>
                        <option value="v2.1.5">v2.1.5</option>
                        <option value="v2.0.0">v2.0.0</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'notifications' && (
                <div>
                  <h2 className="text-lg font-medium text-gray-900 mb-4">Notification Settings</h2>
                  
                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="emailAlerts"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.notifications.emailAlerts}
                          onChange={(e) => handleInputChange('notifications', 'emailAlerts', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="emailAlerts" className="font-medium text-gray-700">Email Alerts</label>
                        <p className="text-gray-500">Receive email notifications for important events</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="highRiskAlerts"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.notifications.highRiskAlerts}
                          onChange={(e) => handleInputChange('notifications', 'highRiskAlerts', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="highRiskAlerts" className="font-medium text-gray-700">High Risk Patient Alerts</label>
                        <p className="text-gray-500">Get notified when high-risk patients are identified</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="scanCompletionNotifications"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.notifications.scanCompletionNotifications}
                          onChange={(e) => handleInputChange('notifications', 'scanCompletionNotifications', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="scanCompletionNotifications" className="font-medium text-gray-700">Scan Completion Notifications</label>
                        <p className="text-gray-500">Get notified when scan analysis is complete</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="weeklyReports"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.notifications.weeklyReports}
                          onChange={(e) => handleInputChange('notifications', 'weeklyReports', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="weeklyReports" className="font-medium text-gray-700">Weekly Summary Reports</label>
                        <p className="text-gray-500">Receive weekly email summaries of system activity</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'security' && (
                <div>
                  <h2 className="text-lg font-medium text-gray-900 mb-4">Security Settings</h2>
                  
                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="twoFactorAuth"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.security.twoFactorAuth}
                          onChange={(e) => handleInputChange('security', 'twoFactorAuth', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="twoFactorAuth" className="font-medium text-gray-700">Two-Factor Authentication</label>
                        <p className="text-gray-500">Require two-factor authentication for all users</p>
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="sessionTimeout" className="block text-sm font-medium text-gray-700">
                        Session Timeout (minutes)
                      </label>
                      <input
                        type="number"
                        id="sessionTimeout"
                        min="5"
                        max="120"
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                        value={settings.security.sessionTimeout}
                        onChange={(e) => handleInputChange('security', 'sessionTimeout', parseInt(e.target.value))}
                      />
                    </div>
                    
                    <div className="flex items-start">
                      <div className="flex items-center h-5">
                        <input
                          id="dataEncryption"
                          type="checkbox"
                          className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                          checked={settings.security.dataEncryption}
                          onChange={(e) => handleInputChange('security', 'dataEncryption', e.target.checked)}
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="dataEncryption" className="font-medium text-gray-700">Enhanced Data Encryption</label>
                        <p className="text-gray-500">Enable additional encryption for sensitive patient data</p>
                      </div>
                    </div>
                    
                    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                      <div className="flex">
                        <div className="flex-shrink-0">
                          <AlertCircle className="h-5 w-5 text-yellow-400" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm text-yellow-700">
                            Changes to security settings may require users to log in again.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-8 pt-5 border-t border-gray-200">
                <div className="flex justify-end">
                  <button
                    type="button"
                    className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    onClick={handleSaveSettings}
                  >
                    <Save size={16} className="mr-2" />
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;