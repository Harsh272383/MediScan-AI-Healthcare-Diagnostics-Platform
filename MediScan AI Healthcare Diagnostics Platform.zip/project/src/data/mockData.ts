import { PatientData, ScanResult, ChartData } from '../types';

export const patients: PatientData[] = [
  {
    id: '1',
    name: 'Emma Johnson',
    age: 58,
    gender: 'Female',
    riskScore: 78,
    riskLevel: 'high',
    lastScan: '2025-05-02',
    diagnosis: 'Early-stage pulmonary nodule detected',
    vitalSigns: {
      heartRate: 88,
      bloodPressure: '135/85',
      temperature: 98.6,
      oxygenSaturation: 95,
    },
  },
  {
    id: '2',
    name: 'David Chen',
    age: 45,
    gender: 'Male',
    riskScore: 42,
    riskLevel: 'medium',
    lastScan: '2025-05-03',
    diagnosis: 'Mild coronary artery calcification',
    vitalSigns: {
      heartRate: 72,
      bloodPressure: '128/82',
      temperature: 98.2,
      oxygenSaturation: 97,
    },
  },
  {
    id: '3',
    name: 'Sarah Williams',
    age: 36,
    gender: 'Female',
    riskScore: 15,
    riskLevel: 'low',
    lastScan: '2025-05-01',
    diagnosis: 'No significant findings',
    vitalSigns: {
      heartRate: 68,
      bloodPressure: '118/75',
      temperature: 98.4,
      oxygenSaturation: 99,
    },
  },
  {
    id: '4',
    name: 'Michael Rodriguez',
    age: 62,
    gender: 'Male',
    riskScore: 85,
    riskLevel: 'high',
    lastScan: '2025-05-04',
    diagnosis: 'Suspected early-stage malignancy',
    vitalSigns: {
      heartRate: 92,
      bloodPressure: '142/90',
      temperature: 99.1,
      oxygenSaturation: 93,
    },
  },
  {
    id: '5',
    name: 'Linda Patel',
    age: 49,
    gender: 'Female',
    riskScore: 38,
    riskLevel: 'medium',
    lastScan: '2025-05-02',
    diagnosis: 'Small renal cyst, likely benign',
    vitalSigns: {
      heartRate: 74,
      bloodPressure: '125/80',
      temperature: 98.5,
      oxygenSaturation: 98,
    },
  },
];

export const scanResults: ScanResult[] = [
  {
    id: '1001',
    patientId: '1',
    date: '2025-05-02',
    scanType: 'CT Lung',
    findings: 'Solitary pulmonary nodule in right upper lobe, 1.2cm in diameter. Requires follow-up.',
    confidence: 92,
    imageUrl: 'https://images.pexels.com/photos/4226119/pexels-photo-4226119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    aiAnnotated: true,
  },
  {
    id: '1002',
    patientId: '2',
    date: '2025-05-03',
    scanType: 'Cardiac CT',
    findings: 'Mild coronary artery calcification. Agatston score: 125. Low to moderate cardiovascular risk.',
    confidence: 88,
    imageUrl: 'https://images.pexels.com/photos/4226219/pexels-photo-4226219.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    aiAnnotated: true,
  },
  {
    id: '1003',
    patientId: '3',
    date: '2025-05-01',
    scanType: 'Abdominal MRI',
    findings: 'No significant abnormalities detected. Normal liver, pancreas, spleen, and kidneys.',
    confidence: 96,
    imageUrl: 'https://images.pexels.com/photos/4225886/pexels-photo-4225886.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    aiAnnotated: true,
  },
  {
    id: '1004',
    patientId: '4',
    date: '2025-05-04',
    scanType: 'PET/CT',
    findings: 'FDG-avid lesion in left lower lobe, SUV max 4.8. Suspicious for malignancy. Biopsy recommended.',
    confidence: 89,
    imageUrl: 'https://images.pexels.com/photos/4226882/pexels-photo-4226882.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    aiAnnotated: true,
  },
  {
    id: '1005',
    patientId: '5',
    date: '2025-05-02',
    scanType: 'Renal Ultrasound',
    findings: 'Simple cyst in right kidney, 2.3cm. Bosniak category I. No malignant features.',
    confidence: 94,
    imageUrl: 'https://images.pexels.com/photos/4226733/pexels-photo-4226733.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    aiAnnotated: true,
  },
];

export const getDemoChartData = (): { riskDistribution: ChartData; scanTypes: ChartData; diagnosisAccuracy: ChartData; weeklyScans: ChartData } => {
  // Risk distribution chart
  const riskDistribution: ChartData = {
    labels: ['Low Risk', 'Medium Risk', 'High Risk'],
    datasets: [
      {
        label: 'Patients by Risk Level',
        data: [27, 45, 28],
        backgroundColor: ['#48BB78', '#ECC94B', '#F56565'],
        borderWidth: 0,
      },
    ],
  };

  // Scan types breakdown
  const scanTypes: ChartData = {
    labels: ['CT Scan', 'MRI', 'X-Ray', 'Ultrasound', 'PET Scan'],
    datasets: [
      {
        label: 'Scan Types',
        data: [35, 25, 20, 15, 5],
        backgroundColor: [
          '#3182CE',
          '#38A169',
          '#805AD5',
          '#DD6B20',
          '#D53F8C',
        ],
        borderWidth: 0,
      },
    ],
  };

  // AI diagnosis accuracy
  const diagnosisAccuracy: ChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
    datasets: [
      {
        label: 'AI Diagnosis Accuracy',
        data: [86, 88, 91, 92, 94],
        backgroundColor: 'rgba(49, 130, 206, 0.2)',
        borderColor: '#3182CE',
        borderWidth: 2,
      },
    ],
  };

  // Weekly scans
  const weeklyScans: ChartData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Scans Performed',
        data: [18, 24, 32, 27, 30, 12, 8],
        backgroundColor: 'rgba(56, 161, 105, 0.2)',
        borderColor: '#38A169',
        borderWidth: 2,
      },
    ],
  };

  return { riskDistribution, scanTypes, diagnosisAccuracy, weeklyScans };
};