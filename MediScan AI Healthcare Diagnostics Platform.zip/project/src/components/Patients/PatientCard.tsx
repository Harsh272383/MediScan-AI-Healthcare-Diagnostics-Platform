import React from 'react';
import { PatientData } from '../../types';
import { Heart, Thermometer, Activity, Droplet } from 'lucide-react';

interface PatientCardProps {
  patient: PatientData;
  onClick: (id: string) => void;
}

const PatientCard: React.FC<PatientCardProps> = ({ patient, onClick }) => {
  const getRiskBadgeClass = (level: string) => {
    switch (level) {
      case 'low':
        return 'bg-secondary-100 text-secondary-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-accent-100 text-accent-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-card hover:shadow-card-hover transition-all duration-300 p-6 cursor-pointer transform hover:scale-[1.02]"
      onClick={() => onClick(patient.id)}
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">{patient.name}</h3>
          <p className="text-sm text-gray-500">
            {patient.age} years • {patient.gender}
          </p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getRiskBadgeClass(patient.riskLevel)}`}>
          {patient.riskLevel.charAt(0).toUpperCase() + patient.riskLevel.slice(1)} Risk
        </span>
      </div>
      
      <div className="mt-4">
        <h4 className="text-sm font-medium text-gray-500 mb-2">Latest Diagnosis</h4>
        <p className="text-sm text-gray-800">{patient.diagnosis}</p>
      </div>
      
      <div className="mt-4">
        <h4 className="text-sm font-medium text-gray-500 mb-2">Vital Signs</h4>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center">
            <Heart size={16} className="text-accent-500 mr-2" />
            <span className="text-sm">{patient.vitalSigns.heartRate} bpm</span>
          </div>
          <div className="flex items-center">
            <Droplet size={16} className="text-primary-500 mr-2" />
            <span className="text-sm">{patient.vitalSigns.bloodPressure}</span>
          </div>
          <div className="flex items-center">
            <Thermometer size={16} className="text-orange-500 mr-2" />
            <span className="text-sm">{patient.vitalSigns.temperature}°F</span>
          </div>
          <div className="flex items-center">
            <Activity size={16} className="text-secondary-500 mr-2" />
            <span className="text-sm">{patient.vitalSigns.oxygenSaturation}% O₂</span>
          </div>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-500">Last scan: {new Date(patient.lastScan).toLocaleDateString()}</span>
          <div className="bg-gray-100 h-2 rounded-full w-24">
            <div 
              className={`h-2 rounded-full ${
                patient.riskLevel === 'low' ? 'bg-secondary-500' : 
                patient.riskLevel === 'medium' ? 'bg-yellow-500' : 'bg-accent-500'
              }`}
              style={{ width: `${patient.riskScore}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientCard;