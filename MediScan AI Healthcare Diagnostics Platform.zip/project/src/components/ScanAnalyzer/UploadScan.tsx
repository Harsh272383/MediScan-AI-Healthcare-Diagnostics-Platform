import React, { useState } from 'react';
import { Upload, FileUp, Check, AlertTriangle } from 'lucide-react';

const UploadScan: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [fileName, setFileName] = useState<string | null>(null);
  
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };
  
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };
  
  const handleFile = (file: File) => {
    // Simulate file upload and processing
    setFileName(file.name);
    setIsUploading(true);
    
    // Simulate AI model processing
    setTimeout(() => {
      setIsUploading(false);
      setUploadStatus('success');
      // In a real app, you would send the file to your AI model here
    }, 3000);
  };
  
  const reset = () => {
    setFileName(null);
    setUploadStatus('idle');
  };
  
  return (
    <div className="bg-white rounded-xl shadow-card p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Upload New Scan</h2>
      
      {uploadStatus === 'idle' ? (
        <div 
          className={`border-2 border-dashed ${dragActive ? 'border-primary-500 bg-primary-50' : 'border-gray-300'} rounded-lg p-6 transition-colors duration-150 ease-in-out`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <div className="flex flex-col items-center justify-center space-y-4">
            <div className="p-3 bg-primary-100 text-primary-600 rounded-full">
              <Upload size={24} />
            </div>
            <div className="text-center">
              <p className="text-base font-medium text-gray-700">
                {isUploading ? `Uploading ${fileName}...` : 'Drag and drop scan files here'}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                {isUploading ? 'Processing with AI models...' : 'or click to browse from your computer'}
              </p>
            </div>
            
            {isUploading ? (
              <div className="w-full mt-4">
                <div className="w-full bg-gray-100 rounded-full h-2.5">
                  <div className="bg-primary-600 h-2.5 rounded-full animate-pulse" style={{ width: '75%' }}></div>
                </div>
              </div>
            ) : (
              <label className="cursor-pointer">
                <span className="px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-md hover:bg-primary-700 transition-colors duration-150 ease-in-out flex items-center">
                  <FileUp size={16} className="mr-2" />
                  Browse Files
                </span>
                <input type="file" className="hidden" accept="image/*" onChange={handleFileInput} />
              </label>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-gray-50 rounded-lg p-6">
          <div className="flex flex-col items-center justify-center space-y-4">
            <div className={`p-3 ${uploadStatus === 'success' ? 'bg-secondary-100 text-secondary-600' : 'bg-accent-100 text-accent-600'} rounded-full`}>
              {uploadStatus === 'success' ? <Check size={24} /> : <AlertTriangle size={24} />}
            </div>
            <div className="text-center">
              <p className="text-lg font-medium text-gray-800">
                {uploadStatus === 'success' ? 'Scan Uploaded Successfully' : 'Error Uploading Scan'}
              </p>
              <p className="text-sm text-gray-500 mt-1">{fileName}</p>
            </div>
            
            {uploadStatus === 'success' && (
              <p className="text-sm text-gray-600 bg-secondary-50 p-3 rounded-lg border border-secondary-100">
                AI analysis complete. The scan has been processed and is ready for review.
              </p>
            )}
            
            <div className="flex space-x-3">
              <button
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-50 transition-colors duration-150"
                onClick={reset}
              >
                Upload Another
              </button>
              {uploadStatus === 'success' && (
                <button className="px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-md hover:bg-primary-700 transition-colors duration-150">
                  View Analysis
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UploadScan;