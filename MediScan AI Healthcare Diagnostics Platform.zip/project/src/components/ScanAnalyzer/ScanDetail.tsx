import React from 'react';
import { ScanResult } from '../../types';

interface ScanDetailProps {
  scan: ScanResult;
}

const ScanDetail: React.FC<ScanDetailProps> = ({ scan }) => {
  return (
    <div className="bg-white rounded-xl shadow-card p-6">
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="lg:w-1/2 overflow-hidden">
          <div className="relative group">
            <img 
              src={scan.imageUrl} 
              alt={`Scan ${scan.id}`} 
              className="rounded-lg w-full h-auto object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute top-3 right-3 flex">
              {scan.aiAnnotated && (
                <span className="bg-primary-100 text-primary-800 text-xs px-2 py-1 rounded-full font-medium">
                  AI Annotated
                </span>
              )}
            </div>
          </div>
          
          <div className="mt-6">
            <h3 className="text-lg font-semibold">AI Confidence Score</h3>
            <div className="mt-2 bg-gray-100 h-3 rounded-full overflow-hidden">
              <div 
                className={`h-3 rounded-full ${
                  scan.confidence >= 90 ? 'bg-secondary-500' : 
                  scan.confidence >= 75 ? 'bg-yellow-500' : 
                  'bg-accent-500'
                }`}
                style={{ width: `${scan.confidence}%` }}
              ></div>
            </div>
            <div className="mt-1 flex justify-between">
              <span className="text-xs text-gray-500">0%</span>
              <span className="text-xs font-medium">
                {scan.confidence}% confident
              </span>
              <span className="text-xs text-gray-500">100%</span>
            </div>
          </div>
        </div>

        <div className="lg:w-1/2">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">{scan.scanType}</h2>
              <p className="text-sm text-gray-500 mt-1">Scan ID: {scan.id}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">Date</h3>
              <p className="text-base text-gray-800 mt-1">{new Date(scan.date).toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500">AI Findings</h3>
              <p className="text-base text-gray-800 mt-1 leading-relaxed">{scan.findings}</p>
            </div>
            
            <div className="bg-primary-50 rounded-lg p-4 border-l-4 border-primary-500">
              <h3 className="text-sm font-medium text-primary-800">AI Interpretation</h3>
              <p className="text-sm text-primary-700 mt-2">
                The AI model has identified specific patterns consistent with {
                  scan.confidence >= 90 ? 'high confidence findings' : 
                  scan.confidence >= 75 ? 'moderate confidence findings' : 
                  'low confidence findings'
                }. {
                  scan.confidence >= 80 ? 
                  'The model recommends clinical correlation and appropriate follow-up based on these findings.' : 
                  'The model suggests further review by a specialist to confirm these preliminary findings.'
                }
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScanDetail;