import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Plus, Activity, Users, FileText, Settings, Stethoscope } from 'lucide-react';

const NavBar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path ? 'bg-primary-700 text-white' : 'text-primary-100 hover:bg-primary-700/50';
  };

  const menuItems = [
    { path: '/', icon: <Activity size={20} />, label: 'Dashboard' },
    { path: '/patients', icon: <Users size={20} />, label: 'Patients' },
    { path: '/scan-analyzer', icon: <Stethoscope size={20} />, label: 'Scan Analyzer' },
    { path: '/reports', icon: <FileText size={20} />, label: 'Reports' },
    { path: '/settings', icon: <Settings size={20} />, label: 'Settings' },
  ];

  return (
    <nav className="bg-primary-800 text-white">
      {/* Desktop navigation */}
      <div className="hidden md:flex h-screen w-64 flex-col fixed inset-y-0">
        <div className="flex items-center justify-center h-16 px-4 bg-primary-900">
          <Stethoscope className="mr-2" size={24} />
          <h1 className="text-xl font-bold">MediScan AI</h1>
        </div>
        <div className="flex-1 overflow-y-auto py-4 px-3 bg-primary-800">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center p-2 rounded-lg transition-colors duration-150 ease-in-out ${isActive(
                    item.path
                  )}`}
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div className="p-4 bg-primary-900">
          <button className="flex items-center justify-center w-full p-2 text-sm font-medium rounded-lg bg-secondary-500 hover:bg-secondary-600 text-white transition-colors duration-150 ease-in-out">
            <Plus size={18} className="mr-2" />
            New Scan
          </button>
        </div>
      </div>

      {/* Mobile navigation */}
      <div className="md:hidden">
        <div className="flex items-center justify-between p-4 bg-primary-900">
          <div className="flex items-center">
            <Stethoscope className="mr-2" size={24} />
            <h1 className="text-xl font-bold">MediScan AI</h1>
          </div>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 rounded-md text-primary-100 hover:bg-primary-800 focus:outline-none"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="px-2 pt-2 pb-3 space-y-1 bg-primary-800">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center p-3 rounded-md ${isActive(item.path)}`}
                onClick={() => setIsMenuOpen(false)}
              >
                {item.icon}
                <span className="ml-3">{item.label}</span>
              </Link>
            ))}
            <button className="flex items-center justify-center w-full mt-4 p-2 text-sm font-medium rounded-lg bg-secondary-500 hover:bg-secondary-600 text-white">
              <Plus size={18} className="mr-2" />
              New Scan
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};

export default NavBar;